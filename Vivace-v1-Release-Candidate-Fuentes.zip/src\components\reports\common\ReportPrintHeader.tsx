import Image from "next/image";

import type {
  ReactNode,
} from "react";

import {
  formatReportDateTime,
} from "@/utils/reportFormatters";

interface ReportPrintHeaderProps {
  organization: string;
  reportTitle: string;
  subtitle?: string;
  generatedAt: string;
  logoSrc?: string;
  rightContent?: ReactNode;
}

export default function ReportPrintHeader({
  organization,
  reportTitle,
  subtitle,
  generatedAt,
  logoSrc = "/images/logo-ecv-v2.png",
  rightContent,
}: ReportPrintHeaderProps) {
  return (
    <section className="rounded-2xl border border-slate-200 bg-white px-6 py-5 shadow-sm">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-4">
          <Image
            src={logoSrc}
            alt={organization}
            width={160}
            height={56}
            priority
            className="h-14 w-auto object-contain"
          />

          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-emerald-800">
              {organization}
            </p>

            <h2 className="mt-1 text-xl font-bold text-slate-900">
              {reportTitle}
            </h2>

            {subtitle ? (
              <p className="mt-1 text-sm text-slate-500">
                {subtitle}
              </p>
            ) : null}
          </div>
        </div>

        <div className="text-left sm:text-right">
          {rightContent}

          <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">
            Generado
          </p>

          <p className="mt-1 text-sm font-medium text-slate-700">
            {formatReportDateTime(
              generatedAt,
            )}
          </p>
        </div>
      </div>
    </section>
  );
}